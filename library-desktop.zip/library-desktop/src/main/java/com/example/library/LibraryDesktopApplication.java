package com.example.library;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibraryDesktopApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibraryDesktopApplication.class, args);
	}

}
